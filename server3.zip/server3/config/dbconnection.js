import mongoose from "mongoose";

const dbconnection =async ()=>{
  try {
    const conn = await mongoose.connect(process.env.db)
    console.log("connected to db" , conn.connection.port)
  } catch (error) {
    console.log("connection cancelled")
  }
}

export default  dbConnection;